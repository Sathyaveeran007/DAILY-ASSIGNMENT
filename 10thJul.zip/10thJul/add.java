public class add {
    public static void main(String[] args) {
        int a = 10;
        int b = 9;
        int c = a + b; 
        System.out.println("Sum is: " + c);
    }
}
