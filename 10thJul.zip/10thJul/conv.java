public class conv {
    public static void main(String[] args) {
        double c, f;
        c = 32.0;
        f = (9.0 / 5.0) * c + 32.0;
        System.out.println("Celsius: " + c + " Fahrenheit: " + f);
    }
}
