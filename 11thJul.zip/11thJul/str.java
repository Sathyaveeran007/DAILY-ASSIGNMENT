import java.util.*;
public class str {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String userInput = sc.nextLine();
        System.out.println("String entered is: " + userInput);
    }
}
