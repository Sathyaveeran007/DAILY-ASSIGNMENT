import java.util.*;
public class typeConv {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        double b = a;
        System.out.println(b);
        
    }
}