class Add1
{
    int a;
    int b;
    int c;
    void get();
    {
        a=10;
        b=20;
    }
    void cal()
    {
        c=a+b;
    }
    void disp()
    {
        System.out.println("output"+c);
    }
}
class Add1Test
{
    public static void main(string arg[])
}